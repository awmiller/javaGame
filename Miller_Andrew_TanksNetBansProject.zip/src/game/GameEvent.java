/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.awt.Dimension;
import java.awt.event.KeyEvent;

/**
 *
 * @author awmil_000
 */
public class GameEvent {
      protected int type;
    
    public static final int MOVE_THIS_PIECE = 0;
    public static final int ATTACK_EVENT = 1;
   
}
