/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package map;


/**
 *
 * @author awmil_000
 */
public class MapTile {
    public static int PixelSquare = 40;
    public int id;
    public MapTile(int ID){id = ID;}
}
